# Robot's Code

  The robot's functions are seperated into two parts: the web server and the robot controller.
  The web server's main function is to communicate with us, the user and gives us the ability to send commands and receive data from the robot controller.
  The robot controller receives commands and sends data to the web server and acts upon those commands to make the robot move.
  
## Robot Controller

No information is available at this time.

## Web Server

No information is availible at this time.
